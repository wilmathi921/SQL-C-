﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EmployeeRegistration
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            string ConnectionString = "Data Source = (localdb)\\MSSQLLocalDb;Initial Catalog=SD12C;Integrated Security=True;";
            SqlConnection connection = new SqlConnection(ConnectionString);
            connection.Open();

            string queryString = "SELECT EmployeeNumber, FamilyName, FirstName, MiddleName, Address, BirthDate, Gender FROM tblEmployee";
            var command = new SqlCommand(queryString, connection);
            var reader = command.ExecuteReader();

            while(reader.Read())
            {
                string employeeNumberString = reader["EmployeeNumber"].ToString();
                string familyNameString = reader["FamilyName"].ToString();
                string firstNameString = reader["FirstName"].ToString();
                string middleNameString = reader["MiddleName"].ToString();
                string addressString = reader["Address"].ToString();
                string birthddateString = reader["Birthdate"].ToString();
                string genderString = reader["Gender"].ToString();

                ListViewItem lvi = new ListViewItem(employeeNumberString);
                lvi.SubItems.Add(familyNameString);
                lvi.SubItems.Add(firstNameString);
                lvi.SubItems.Add(middleNameString);
                lvi.SubItems.Add(addressString);
                lvi.SubItems.Add(birthddateString);
                lvi.SubItems.Add(genderString);
                listView1.Items.Add(lvi);
            }
            reader.Close();
            connection.Close();

            // Provide Alternating Background Color of Rows in ListView1
            for (int i = 0; i < listView1.Items.Count; i++)
            {
                if(listView1.Items[i].Index % 2 == 0)
                {
                    listView1.Items[i].BackColor = Color.White;
                }

                else
                {
                    listView1.Items[i].BackColor = Color.Yellow;
                }
            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Delete from Database SD12C
            string itemFirstColumn = listView1.SelectedItems[0].SubItems[0].Text;
            string ConnectionString = "Data Source = (localdb)\\MSSQLLocalDb;Initial Catalog=SD12C;Integrated Security=True;";
            SqlConnection connection = new SqlConnection(ConnectionString);
            connection.Open();

            string deleteString = "DELETE FROM tblEmployee WHERE EmployeeNumber = @IDParameter;";
            SqlParameter param = new SqlParameter();
            param.ParameterName = "@IDParameter";
            param.Value = itemFirstColumn;
            var command = new SqlCommand(deleteString, connection);
            command.Parameters.Add(param);
            command.ExecuteNonQuery();
            connection.Close();

            // Delete from ListView1
            listView1.Items.Remove(listView1.SelectedItems[0]);
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }
    }
}
