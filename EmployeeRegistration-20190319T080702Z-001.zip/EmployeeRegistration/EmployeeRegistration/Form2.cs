﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace EmployeeRegistration
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            string ConnectionString = "Data Source = (localdb)\\MSSQLLocalDb;Initial Catalog=SD12C;Integrated Security=True;";
            SqlConnection connection = new SqlConnection(ConnectionString);
            connection.Open();

            string queryString = "SELECT EmployeeNumber FROM tblEmployee;";
            var command = new SqlCommand(queryString,connection);
            var reader = command.ExecuteReader();

            while (reader.Read())
            {
                string empNumberString = reader["EmployeeNumber"].ToString();
                comboBox1.Items.Add(empNumberString);
            }
            reader.Close();
            connection.Close();

            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Loads all the Files Input If IDNumber Matches
            string ConnectionString = "Data Source = (localdb)\\MSSQLLocalDb;Initial Catalog=SD12C;Integrated Security=True;";
            SqlConnection connection = new SqlConnection(ConnectionString);
            connection.Open();

            string queryString = "SELECT * FROM tblEmployee WHERE EmployeeNumber = @IDNumberParameter;";
            SqlParameter param = new SqlParameter();
            param.ParameterName = "@IDNumberParameter";
            param.Value = comboBox1.Text;

            var command = new SqlCommand(queryString, connection);
            command.Parameters.Add(param);
            var reader = command.ExecuteReader();

            while (reader.Read())
            {
                textBox1.Text = reader["FamilyName"].ToString();
                textBox2.Text = reader["FirstName"].ToString();
                textBox3.Text = reader["MiddleName"].ToString();
                textBox4.Text = reader["Address"].ToString();
                textBox5.Text = reader["BirthDate"].ToString();
                textBox6.Text = reader["Gender"].ToString();
                byte[] img = (byte[])(reader["Picture"]);
                MemoryStream ms = new MemoryStream(img);
                pictureBox1.Image = Image.FromStream(ms);
            }
            reader.Close();
            connection.Close();

            button1.Enabled = true;
            button2.Enabled = false;
            button3.Enabled = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            button1.Enabled = false;
            button2.Enabled = true;
            button3.Enabled = true;

            textBox1.Enabled = true;
            textBox2.Enabled = true;
            textBox3.Enabled = true;
            textBox4.Enabled = true;
            textBox5.Enabled = true;
            textBox6.Enabled = true;
            comboBox1.Enabled = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string ConnectionString = "Data Source = (localdb)\\MSSQLLocalDb;Initial Catalog=SD12C;Integrated Security=True;";
            SqlConnection connection = new SqlConnection(ConnectionString);
            connection.Open();

            string queryString = "UPDATE tblEmployee SET FamilyName = @FamilyNameParameter, FirstName = @FirstNameParameter, MiddleName = @MiddleNameParameter, Address = @AddressParameter, BirthDate = @BirthDateParameter, Gender = @GenderParameter WHERE EmployeeNumber = @EmployeeNumberParameter";

            SqlParameter param1 = new SqlParameter();
            param1.ParameterName = "@FamilyNameParameter";
            param1.Value = textBox1.Text;

            SqlParameter param2 = new SqlParameter();
            param2.ParameterName = "@FirstNameParameter";
            param2.Value = textBox2.Text;

            SqlParameter param3 = new SqlParameter();
            param3.ParameterName = "@MiddleNameParameter";
            param3.Value = textBox3.Text;

            SqlParameter param4 = new SqlParameter();
            param4.ParameterName = "@AddressParameter";
            param4.Value = textBox4.Text;

            SqlParameter param5 = new SqlParameter();
            param5.ParameterName = "@BirthDateParameter";
            param5.Value = textBox5.Text;

            SqlParameter param6 = new SqlParameter();
            param6.ParameterName = "@GenderParameter";
            param6.Value = textBox6.Text;

            SqlParameter param7 = new SqlParameter();
            param7.ParameterName = "@EmployeeNumberParameter";
            param7.Value = comboBox1.Text;

            SqlCommand command = new SqlCommand(queryString, connection);

            command.Parameters.Add(param1);
            command.Parameters.Add(param2);
            command.Parameters.Add(param3);
            command.Parameters.Add(param4);
            command.Parameters.Add(param5);
            command.Parameters.Add(param6);
            command.Parameters.Add(param7);

            command.ExecuteNonQuery(); // Executes the Saving
            connection.Close(); // Closes the Database

            MessageBox.Show("File Saved.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Ignore
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            string ConnectionString = "Data Source = (localdb)\\MSSQLLocalDb;Initial Catalog=SD12C;Integrated Security=True;";
            SqlConnection connection = new SqlConnection(ConnectionString);
            connection.Open();

            string queryString = "DELETE tblEmployee WHERE EmployeeNumber = @EmployeeNumberParameter";

            SqlParameter param1 = new SqlParameter();
            param1.ParameterName = "@FamilyNameParameter";
            param1.Value = textBox1.Text;

            SqlParameter param2 = new SqlParameter();
            param2.ParameterName = "@FirstNameParameter";
            param2.Value = textBox2.Text;

            SqlParameter param3 = new SqlParameter();
            param3.ParameterName = "@MiddleNameParameter";
            param3.Value = textBox3.Text;

            SqlParameter param4 = new SqlParameter();
            param4.ParameterName = "@AddressParameter";
            param4.Value = textBox4.Text;

            SqlParameter param5 = new SqlParameter();
            param5.ParameterName = "@BirthDateParameter";
            param5.Value = textBox5.Text;

            SqlParameter param6 = new SqlParameter();
            param6.ParameterName = "@GenderParameter";
            param6.Value = textBox6.Text;

            SqlParameter param7 = new SqlParameter();
            param7.ParameterName = "@EmployeeNumberParameter";
            param7.Value = comboBox1.Text;

            SqlCommand command = new SqlCommand(queryString, connection);

            command.Parameters.Add(param1);
            command.Parameters.Add(param2);
            command.Parameters.Add(param3);
            command.Parameters.Add(param4);
            command.Parameters.Add(param5);
            command.Parameters.Add(param6);
            command.Parameters.Add(param7);

            command.ExecuteNonQuery(); // Executes the Saving
            connection.Close(); // Closes the Database

            MessageBox.Show("Delete.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
