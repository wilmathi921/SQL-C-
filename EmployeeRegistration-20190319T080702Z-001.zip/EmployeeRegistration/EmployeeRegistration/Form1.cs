﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace EmployeeRegistration
{
    public partial class Form1 : Form
    {
        string imgLoc = string.Empty;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DateTime today = DateTime.Now;
            textBox6.Text = today.ToString("d");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "Choose a Picture";
            dlg.Filter = "JPG Files(*.jpg)|*.jpg|GIF Files(*.gif)|*.gif|All Files(*.*)|*.*|PNG Files(*.png)|*.png";
            if(dlg.ShowDialog()==DialogResult.OK)
            {
                imgLoc = dlg.FileName.ToString();
                pictureBox1.ImageLocation = imgLoc;
            } 
        }

        private void button2_Click(object sender, EventArgs e)
        {
            /* This Saves the Information */
            string ConnectionString = "Data Source = (localdb)\\MSSQLLocalDb;Initial Catalog=SD12C;Integrated Security=True;";
            SqlConnection connection = new SqlConnection(ConnectionString);
            connection.Open();
            byte[] img = null;
            FileStream fs = new FileStream(imgLoc,FileMode.Open,FileAccess.Read);
            BinaryReader br = new BinaryReader(fs);
            img = br.ReadBytes((int)fs.Length);

            // string queryString = "INSERT INTO tblEmployee VALUES" + "('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "','" + textBox6.Text + "','" + comboBox1.Text + "', @img)";
            string queryString = "INSERT INTO tblEmployee VALUES(@EmployeeNumberParameter,@FamilyNameParameter,@FirstNameParameter,@MiddleNameParameter,@AddressParameter,@BirthDateParameter,@GenderParameter,@img)";

            SqlParameter param1 = new SqlParameter();
            param1.ParameterName = "@EmployeeNumberParameter";
            param1.Value = textBox1.Text;

            SqlParameter param2 = new SqlParameter();
            param2.ParameterName = "@FamilyNameParameter";
            param2.Value = textBox2.Text;

            SqlParameter param3 = new SqlParameter();
            param3.ParameterName = "@FirstNameParameter";
            param3.Value = textBox3.Text;

            SqlParameter param4 = new SqlParameter();
            param4.ParameterName = "@MiddleNameParameter";
            param4.Value = textBox4.Text;

            SqlParameter param5 = new SqlParameter();
            param5.ParameterName = "@AddressParameter";
            param5.Value = textBox5.Text;

            SqlParameter param6 = new SqlParameter();
            param6.ParameterName = "@BirthDateParameter";
            param6.Value = textBox6.Text;

            SqlParameter param7 = new SqlParameter();
            param7.ParameterName = "@GenderParameter";
            param7.Value = comboBox1.Text;

            SqlCommand command = new SqlCommand(queryString,connection);

            command.Parameters.Add(param1);
            command.Parameters.Add(param2);
            command.Parameters.Add(param3);
            command.Parameters.Add(param4);
            command.Parameters.Add(param5);
            command.Parameters.Add(param6);
            command.Parameters.Add(param7);
            command.Parameters.Add(new SqlParameter("@img",img));
            command.ExecuteNonQuery(); // Executes the Saving
            connection.Close(); // Closes the Database
            MessageBox.Show("File Saved.","Success",MessageBoxButtons.OK,MessageBoxIcon.Information);
        }
    }
}
