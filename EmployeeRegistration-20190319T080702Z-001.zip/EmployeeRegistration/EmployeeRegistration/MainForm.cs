﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmployeeRegistration
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void newEmployeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 aForm = new Form1();
            aForm.Show();
            this.Close();
        }

        private void searchEmployeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 aForm = new Form2();
            aForm.Show();
        }

        private void displayAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form3 aForm = new Form3();
            aForm.Show();
        }
    }
}
